// Point this at your deployed backend, or http://localhost:3000/api during
// local dev (use your machine's LAN IP instead of localhost for a physical device).
const API_BASE_URL = 'http://localhost:3000/api';

let authToken: string | undefined;

export function setAuthToken(token: string) {
  authToken = token;
}

export async function login(email: string, password: string) {
  const res = await fetch(`${API_BASE_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  if (!res.ok) throw new Error('Login failed');
  const data = await res.json();
  setAuthToken(data.accessToken);
  return data;
}

type StreamEvent =
  | { type: 'token'; token: string }
  | { type: 'done'; sessionId: string }
  | { type: 'error'; message: string };

interface StreamHandlers {
  onToken: (token: string) => void;
  onDone: (sessionId: string) => void;
  onError: (message: string) => void;
}

/**
 * Consumes the backend's SSE stream using fetch + ReadableStream, per the
 * MVP streaming approach in the spec. Parses `data: {...}\n\n` frames as
 * they arrive and dispatches them to the message store.
 */
export async function sendMessageStream(
  content: string,
  sessionId: string | undefined,
  handlers: StreamHandlers,
) {
  const res = await fetch(`${API_BASE_URL}/chat/message/stream`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: authToken ? `Bearer ${authToken}` : '',
    },
    body: JSON.stringify({ content, sessionId }),
  });

  if (!res.ok || !res.body) {
    handlers.onError('Could not reach the assistant. Check your connection and try again.');
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const frames = buffer.split('\n\n');
    buffer = frames.pop() ?? '';

    for (const frame of frames) {
      const line = frame.trim();
      if (!line.startsWith('data:')) continue;

      try {
        const event: StreamEvent = JSON.parse(line.slice(5).trim());
        if (event.type === 'token') handlers.onToken(event.token);
        else if (event.type === 'done') handlers.onDone(event.sessionId);
        else if (event.type === 'error') handlers.onError(event.message);
      } catch {
        // Ignore malformed frames rather than crashing the stream.
      }
    }
  }
}

export async function fetchSessionMessages(sessionId: string) {
  const res = await fetch(`${API_BASE_URL}/chat/sessions/${sessionId}/messages`, {
    headers: { Authorization: authToken ? `Bearer ${authToken}` : '' },
  });
  if (!res.ok) throw new Error('Could not load messages');
  return res.json();
}
