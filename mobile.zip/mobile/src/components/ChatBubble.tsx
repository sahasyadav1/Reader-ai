import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { ChatMessage } from '../store/chatStore';

export default function ChatBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === 'user';
  return (
    <View
      style={[styles.row, { justifyContent: isUser ? 'flex-end' : 'flex-start' }]}
      accessibilityLabel={`${isUser ? 'You' : 'Assistant'} said: ${message.content}`}
    >
      <View style={[styles.bubble, isUser ? styles.userBubble : styles.assistantBubble]}>
        <Text style={styles.text}>{message.content || ' '}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', marginVertical: 4, paddingHorizontal: 12 },
  bubble: {
    maxWidth: '80%',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 18,
  },
  userBubble: { backgroundColor: colors.bubbleUser, borderBottomRightRadius: 4 },
  assistantBubble: { backgroundColor: colors.bubbleAssistant, borderBottomLeftRadius: 4 },
  text: { color: colors.text, fontSize: 16, lineHeight: 21 },
});
