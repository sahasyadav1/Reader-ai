import React, { useRef, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  FlatList,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../theme/colors';
import { useChatStore, ChatMessage } from '../store/chatStore';
import { sendMessageStream } from '../services/api';
import ChatBubble from '../components/ChatBubble';
import TypingIndicator from '../components/TypingIndicator';

let nextId = 0;
const genId = () => `msg-${Date.now()}-${nextId++}`;

export default function AssistantScreen() {
  const navigation = useNavigation<any>();
  const [input, setInput] = useState('');
  const [hasError, setHasError] = useState(false);
  const listRef = useRef<FlatList<ChatMessage>>(null);

  const { sessionId, messages, isSending, setSessionId, addMessage, appendToLastMessage, finishStreaming, setSending } =
    useChatStore();

  const scrollToEnd = () => setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 50);

  const handleSend = async (textOverride?: string) => {
    const text = (textOverride ?? input).trim();
    if (!text || isSending) return;

    setHasError(false);
    setInput('');
    addMessage({ id: genId(), role: 'user', content: text });
    addMessage({ id: genId(), role: 'assistant', content: '', isStreaming: true });
    setSending(true);
    scrollToEnd();

    await sendMessageStream(text, sessionId, {
      onToken: (token) => {
        appendToLastMessage(token);
        scrollToEnd();
      },
      onDone: (newSessionId) => {
        setSessionId(newSessionId);
        finishStreaming();
        setSending(false);
      },
      onError: () => {
        finishStreaming();
        setSending(false);
        setHasError(true);
      },
    });
  };

  const retryLast = () => {
    const lastUser = [...messages].reverse().find((m) => m.role === 'user');
    if (lastUser) handleSend(lastUser.content);
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={90}
    >
      <View style={styles.header}>
        <Pressable
          onPress={() => navigation.goBack()}
          accessibilityLabel="Back to home"
          hitSlop={12}
          style={styles.headerButton}
        >
          <Text style={styles.headerButtonText}>‹</Text>
        </Pressable>
        <Text style={styles.headerTitle}>Assistant</Text>
        <View style={styles.headerButton} />
      </View>

      {messages.length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyTitle}>Hi there 👋</Text>
          <Text style={styles.emptySubtitle}>What can I help you with today?</Text>
        </View>
      ) : (
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(m) => m.id}
          renderItem={({ item }) =>
            item.isStreaming && !item.content ? <TypingIndicator /> : <ChatBubble message={item} />
          }
          contentContainerStyle={{ paddingVertical: 12 }}
        />
      )}

      {hasError && (
        <View style={styles.errorBar}>
          <Text style={styles.errorText}>Something went wrong.</Text>
          <Pressable onPress={retryLast} hitSlop={8}>
            <Text style={styles.retryText}>Retry</Text>
          </Pressable>
        </View>
      )}

      <View style={styles.inputBar}>
        <Pressable
          accessibilityLabel="Voice input"
          hitSlop={12}
          style={styles.micButton}
          onPress={() => {
            // MVP stub: wire up expo-av / react-native-voice here for
            // speech-to-text, then call handleSend(transcript).
          }}
        >
          <Text style={styles.micGlyph}>🎤</Text>
        </Pressable>
        <TextInput
          value={input}
          onChangeText={setInput}
          placeholder="Message your assistant…"
          placeholderTextColor={colors.textMuted}
          style={styles.input}
          multiline
          accessibilityLabel="Message input"
        />
        <Pressable
          onPress={() => handleSend()}
          disabled={!input.trim() || isSending}
          accessibilityLabel="Send message"
          hitSlop={12}
          style={[styles.sendButton, (!input.trim() || isSending) && styles.sendButtonDisabled]}
        >
          <Text style={styles.sendGlyph}>➤</Text>
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 8,
    paddingTop: 12,
    paddingBottom: 8,
  },
  headerButton: { width: 48, height: 48, alignItems: 'center', justifyContent: 'center' },
  headerButtonText: { color: colors.text, fontSize: 28 },
  headerTitle: { color: colors.text, fontSize: 17, fontWeight: '600' },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32 },
  emptyTitle: { color: colors.text, fontSize: 22, fontWeight: '700', marginBottom: 8 },
  emptySubtitle: { color: colors.textMuted, fontSize: 15, textAlign: 'center' },
  errorBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#3F1D1D',
    marginHorizontal: 12,
    marginBottom: 8,
    padding: 10,
    borderRadius: 10,
  },
  errorText: { color: colors.error, fontSize: 14 },
  retryText: { color: colors.text, fontWeight: '700', fontSize: 14 },
  inputBar: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 10,
    paddingVertical: 10,
    gap: 8,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: '#1E293B',
  },
  micButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.surface,
  },
  micGlyph: { fontSize: 18 },
  input: {
    flex: 1,
    minHeight: 44,
    maxHeight: 120,
    backgroundColor: colors.surface,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    color: colors.text,
    fontSize: 16,
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primary,
  },
  sendButtonDisabled: { opacity: 0.4 },
  sendGlyph: { color: colors.text, fontSize: 18 },
});
