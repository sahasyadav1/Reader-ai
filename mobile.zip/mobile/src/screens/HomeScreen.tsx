import React, { useEffect, useRef } from 'react';
import { View, Text, Pressable, StyleSheet, Animated } from 'react-native';
import * as Haptics from 'expo-haptics';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../theme/colors';
import { useDoubleTap } from '../hooks/useDoubleTap';

/**
 * Home Screen: centered logo with a subtle breathing animation.
 * Double-tap the logo to activate the assistant (haptic + ripple),
 * per the core product flow.
 */
export default function HomeScreen() {
  const navigation = useNavigation<any>();
  const breathe = useRef(new Animated.Value(1)).current;
  const ripple = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(breathe, { toValue: 1.06, duration: 1800, useNativeDriver: true }),
        Animated.timing(breathe, { toValue: 1, duration: 1800, useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [breathe]);

  const activateAssistant = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    ripple.setValue(0);
    Animated.timing(ripple, { toValue: 1, duration: 400, useNativeDriver: true }).start(() => {
      navigation.navigate('Assistant');
    });
  };

  const handleTap = useDoubleTap(activateAssistant);

  const rippleScale = ripple.interpolate({ inputRange: [0, 1], outputRange: [1, 2.4] });
  const rippleOpacity = ripple.interpolate({ inputRange: [0, 1], outputRange: [0.35, 0] });

  return (
    <View style={styles.container}>
      <Pressable
        onPress={handleTap}
        accessibilityRole="button"
        accessibilityLabel="Double tap to activate assistant"
        hitSlop={20}
        style={styles.logoWrapper}
      >
        <Animated.View
          pointerEvents="none"
          style={[styles.ripple, { transform: [{ scale: rippleScale }], opacity: rippleOpacity }]}
        />
        <Animated.View style={[styles.logo, { transform: [{ scale: breathe }] }]}>
          <Text style={styles.logoGlyph}>💬✨</Text>
        </Animated.View>
      </Pressable>

      <Text style={styles.tagline}>Double-tap to talk to your assistant</Text>
    </View>
  );
}

const LOGO_SIZE = 140;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoWrapper: {
    width: LOGO_SIZE * 2,
    height: LOGO_SIZE * 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
    borderRadius: LOGO_SIZE / 2,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.primary,
    shadowOpacity: 0.5,
    shadowRadius: 30,
    shadowOffset: { width: 0, height: 0 },
  },
  logoGlyph: {
    fontSize: 48,
  },
  ripple: {
    position: 'absolute',
    width: LOGO_SIZE,
    height: LOGO_SIZE,
    borderRadius: LOGO_SIZE / 2,
    backgroundColor: colors.primary,
  },
  tagline: {
    marginTop: 32,
    color: colors.textMuted,
    fontSize: 15,
  },
});
